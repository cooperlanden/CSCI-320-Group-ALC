#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#include "common.h"
#include "common_threads.h"
#include "zemaphore.h"

/* Global Variables */
int barberChairCount;
Zem_t waitingRoom;
Zem_t chairMutex;
Zem_t doneCut;

/* Simulates giving a haircut */
void performHaircut()
{
    printf("Barber: Cutting hair...\n");
    sleep(1);
    Zem_post(&doneCut);
}

/* Barber thread function */
void *barberWork(void *arg)
{
    while (1) {
        if (barberChairCount > 0) {
            printf("Barber: No customers, sleeping.\n");
            sleep(1);
        } else {
            performHaircut();
        }
    }
    return NULL; // Not reached.
}

/* Simulate a customer receiving a haircut */
void receiveHaircut(int customerID)
{
    Zem_wait(&doneCut);
    sleep(1);
    barberChairCount++;
    printf("Customer #%d: Finished haircut and leaving.\n", customerID);
}

/* Customer thread function */
void *customerRoutine(void *arg)
{
    long long int custNumLong = (long long int) arg;
    int customerID = (int) custNumLong;

    if (barberChairCount == 0) {
        Zem_wait(&waitingRoom);
        printf("Customer #%d: Waiting in the waiting room.\n", customerID);

        while (barberChairCount == 0) {
        }

        Zem_wait(&chairMutex);
        printf("Customer #%d: Sitting in the barber's chair.\n", customerID);
        barberChairCount--;
        Zem_post(&waitingRoom);
        receiveHaircut(customerID);
        Zem_post(&chairMutex);

    } else {
        Zem_wait(&chairMutex);
        barberChairCount--;
        printf("Customer #%d: Immediately took a barber's chair.\n", customerID);
        receiveHaircut(customerID);
        Zem_post(&chairMutex);
    }

    return NULL;
}

int main()
{
    printf("Enter the number of available barber chairs: ");
    scanf("%d", &barberChairCount);

    Zem_init(&waitingRoom, 5);
    Zem_init(&chairMutex, barberChairCount);
    Zem_init(&doneCut, barberChairCount - 1);

    pthread_t barberThread;
    for (int i = 0; i < barberChairCount; i++) {
        Pthread_create(&barberThread, NULL, barberWork, NULL);
    }

    pthread_t customerThread;
    for (int j = 0; j < 9; j++) {
        long long int custID = j;
        Pthread_create(&customerThread, NULL, customerRoutine, (void *)custID);
    }

    Pthread_join(customerThread, NULL);
    Pthread_join(barberThread, NULL);

    return 0;
}
