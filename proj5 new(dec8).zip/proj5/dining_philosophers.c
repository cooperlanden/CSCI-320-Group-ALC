#include "common_threads.h"
#include "common.h"
#include "zemaphore.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define THINKING 0
#define HUNGRY 1
#define EATING 2

int N;
Zem_t *forks;
pthread_mutex_t mutex;
Zem_t *self;
int *state;
int *eat_count;
Zem_t table;

void test(int id) {
    if (state[id] == HUNGRY &&
        state[(id + N - 1) % N] != EATING &&
        state[(id + 1) % N] != EATING) {
        state[id] = EATING;
        Zem_post(&self[id]);
    }
}

void take_forks(int id) {
    pthread_mutex_lock(&mutex);
    state[id] = HUNGRY;
    test(id);
    pthread_mutex_unlock(&mutex);
    Zem_wait(&self[id]);
}

void put_forks(int id) {
    pthread_mutex_lock(&mutex);
    state[id] = THINKING;
    test((id + N - 1) % N);
    test((id + 1) % N);
    pthread_mutex_unlock(&mutex);
}

void *philosopher1(void *arg) {
    int id = *(int *)arg;

    while (1) {
        printf("Philosopher %d (Alg1) is thinking\n", id);
        sleep(rand() % 3);
        printf("Philosopher %d (Alg1) is hungry\n", id);

        Zem_wait(&forks[id]);
        Zem_wait(&forks[(id + 1) % N]);

        pthread_mutex_lock(&mutex);
        eat_count[id]++;
        printf("Philosopher %d (Alg1) is eating. Total eat count: %d\n", id, eat_count[id]);
        pthread_mutex_unlock(&mutex);
        sleep(rand() % 2);

        Zem_post(&forks[id]);
        Zem_post(&forks[(id + 1) % N]);
    }

    return NULL;
}

void *philosopher2(void *arg) {
    int id = *(int *)arg;

    while (1) {
        printf("Philosopher %d (Alg2) is thinking\n", id);
        sleep(rand() % 3);
        printf("Philosopher %d (Alg2) is hungry\n", id);

        take_forks(id);
        eat_count[id]++;
        printf("Philosopher %d (Alg2) is eating. Total eat count: %d\n", id, eat_count[id]);
        sleep(rand() % 2);

        put_forks(id);
    }

    return NULL;
}

void *philosopher3(void *arg) {
    int id = *(int *)arg;

    while (1) {
        printf("Philosopher %d (Alg3) is thinking\n", id);
        sleep(rand() % 3);
        printf("Philosopher %d (Alg3) is hungry and trying to sit at the table\n", id);

        Zem_wait(&table);
        printf("Philosopher %d (Alg3) is now seated at the table\n", id);

        take_forks(id);
        eat_count[id]++;
        printf("Philosopher %d (Alg3) is eating. Total eat count: %d\n", id, eat_count[id]);
        sleep(rand() % 2);

        put_forks(id);
        printf("Philosopher %d (Alg3) is leaving the table\n", id);

        Zem_post(&table);
    }

    return NULL;
}

void run_algorithm(void *(*philosopher_func)(void *)) {
    pthread_t threads[N];
    int ids[N];

    for (int i = 0; i < N; i++) {
        ids[i] = i;
        pthread_create(&threads[i], NULL, philosopher_func, &ids[i]);
    }

    for (int i = 0; i < N; i++) {
        pthread_join(threads[i], NULL);
    }
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <num_philosophers> <algorithm 1-3>\n", argv[0]);
        return -1;
    }

    N = atoi(argv[1]);
    int algorithm = atoi(argv[2]);

    if (N < 3 || N > 20) {
        printf("Number of philosophers must be between 3 and 20\n");
        return -1;
    }

    eat_count = malloc(N * sizeof(int));
    for (int i = 0; i < N; i++) {
        eat_count[i] = 0;
    }

    if (algorithm == 1) {
        forks = malloc(N * sizeof(Zem_t));
        pthread_mutex_init(&mutex, NULL);

        for (int i = 0; i < N; i++) {
            Zem_init(&forks[i], 1);
        }

        run_algorithm(philosopher1);

        free(forks);
        pthread_mutex_destroy(&mutex);

    } else if (algorithm == 2) {
        state = malloc(N * sizeof(int));
        self = malloc(N * sizeof(Zem_t));
        pthread_mutex_init(&mutex, NULL);

        for (int i = 0; i < N; i++) {
            state[i] = THINKING;
            Zem_init(&self[i], 0);
        }

        run_algorithm(philosopher2);

        free(state);
        free(self);
        pthread_mutex_destroy(&mutex);

    } else if (algorithm == 3) {
        state = malloc(N * sizeof(int));
        self = malloc(N * sizeof(Zem_t));
        pthread_mutex_init(&mutex, NULL);

        Zem_init(&table, N - 1);

        for (int i = 0; i < N; i++) {
            state[i] = THINKING;
            Zem_init(&self[i], 0);
        }

        run_algorithm(philosopher3);

        free(state);
        free(self);
        pthread_mutex_destroy(&mutex);

    } else {
        printf("Invalid algorithm choice. Choose 1, 2, or 3.\n");
        free(eat_count);
        return -1;
    }

    free(eat_count);
    return 0;
}
