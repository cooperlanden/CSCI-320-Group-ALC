#ifndef __common_h__
#define __common_h__

#include <sys/time.h>
#include <sys/stat.h>
#include <assert.h>
#include <stddef.h> // For NULL

// Get the current time in seconds (as a double)
double GetTime() {
    struct timeval t;
    int rc = gettimeofday(&t, NULL);
    assert(rc == 0); // Ensure gettimeofday succeeded
    return (double)t.tv_sec + (double)t.tv_usec / 1e6; // Seconds and microseconds
}

// Spin for a specified duration (in seconds)
void Spin(int howlong) {
    double t = GetTime();
    while ((GetTime() - t) < (double)howlong) {
        ; // Busy wait (do nothing)
    }
}

#endif // __common_h__
