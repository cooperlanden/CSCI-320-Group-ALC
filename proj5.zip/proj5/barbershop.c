#include "common_threads.h"
#include "common.h"
#include "zemaphore.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// Maximum number of chairs (for queue implementation)
#define MAX_CHAIRS 100

// Semaphore declarations
Zem_t customers, barber_ready, access_chairs;

// Shared variables
int free_chairs;
int num_chairs;
int num_customers;

// Mutex for synchronized printing
pthread_mutex_t print_lock;

// Queue implementation
typedef struct {
    int front;
    int rear;
    int capacity;
    int *array;
} Queue;

// Initialize the queue
void initQueue(Queue *q, int capacity) {
    q->capacity = capacity;
    q->front = q->rear = 0;
    q->array = (int *)malloc(capacity * sizeof(int));
}

// Check if the queue is empty
int isEmpty(Queue *q) {
    return q->front == q->rear;
}

// Check if the queue is full
int isFull(Queue *q) {
    return (q->rear + 1) % q->capacity == q->front;
}

// Enqueue a customer ID
void enqueue(Queue *q, int customer_id) {
    if (isFull(q)) {
        // Queue is full, should not happen as we control the number of chairs
        return;
    }
    q->array[q->rear] = customer_id;
    q->rear = (q->rear + 1) % q->capacity;
}

// Dequeue a customer ID
int dequeue(Queue *q) {
    if (isEmpty(q)) {
        // Queue is empty, should not happen as we check before dequeueing
        return -1;
    }
    int customer_id = q->array[q->front];
    q->front = (q->front + 1) % q->capacity;
    return customer_id;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <num_customers> <num_chairs>\n", argv[0]);
        return -1;
    }

    num_customers = atoi(argv[1]);
    num_chairs = atoi(argv[2]);

    if (num_chairs > MAX_CHAIRS) {
        printf("Number of chairs exceeds maximum limit (%d).\n", MAX_CHAIRS);
        return -1;
    }

    free_chairs = num_chairs;

    pthread_t barber_thread, customer_threads[num_customers];
    int customer_ids[num_customers];

    // Initialize semaphores
    Zem_init(&customers, 0);      // No customers initially
    Zem_init(&barber_ready, 0);   // Barber is initially not ready
    Zem_init(&access_chairs, 1);  // Mutex for accessing chairs

    // Initialize mutex
    pthread_mutex_init(&print_lock, NULL);

    // Initialize queue
    Queue q;
    initQueue(&q, num_chairs + 1); // +1 to differentiate full vs empty

    // Initialize per-customer semaphores
    Zem_t *customer_sems = malloc(num_customers * sizeof(Zem_t));
    for (int i = 0; i < num_customers; i++) {
        Zem_init(&customer_sems[i], 0);
    }

    // Barber thread function
    void *barber(void *arg) {
        while (1) {
            Zem_wait(&customers); // Wait for a customer

            // Acquire access to chairs
            Zem_wait(&access_chairs);

            free_chairs++; // One chair becomes free

            // Dequeue the next customer
            int customer_id = dequeue(&q);

            // Release access to chairs
            Zem_post(&access_chairs);

            // Notify the specific customer
            Zem_post(&customer_sems[customer_id - 1]);

            // Print barber actions
            pthread_mutex_lock(&print_lock);
            printf("Barber is cutting hair for customer %d.\n", customer_id);
            pthread_mutex_unlock(&print_lock);

            sleep(rand() % 3 + 1); // Simulate haircut

            pthread_mutex_lock(&print_lock);
            printf("Barber finished cutting hair for customer %d.\n", customer_id);
            pthread_mutex_unlock(&print_lock);

            Zem_post(&barber_ready); // Signal that barber is ready
        }
        return NULL;
    }

    // Customer thread function
    void *customer(void *arg) {
        int customer_id = *(int *)arg;

        // Acquire access to chairs
        Zem_wait(&access_chairs);

        if (free_chairs > 0) {
            free_chairs--; // Take a chair

            // Enqueue self
            enqueue(&q, customer_id);

            pthread_mutex_lock(&print_lock);
            printf("Customer %d arrives and waits in the waiting room.\n", customer_id);
            pthread_mutex_unlock(&print_lock);

            Zem_post(&customers); // Notify barber that a customer is waiting

            Zem_post(&access_chairs); // Release access to chairs

            // Wait to be called by the barber
            Zem_wait(&customer_sems[customer_id - 1]);

            pthread_mutex_lock(&print_lock);
            printf("Customer %d is getting a haircut.\n", customer_id);
            pthread_mutex_unlock(&print_lock);

            Zem_wait(&barber_ready); // Wait until barber finishes

        } else {
            // No free chairs
            pthread_mutex_lock(&print_lock);
            printf("Customer %d arrives and leaves (no chairs available).\n", customer_id);
            pthread_mutex_unlock(&print_lock);
            Zem_post(&access_chairs); // Release access to chairs
        }

        return NULL;
    }

    // Create barber thread
    pthread_create(&barber_thread, NULL, barber, NULL);

    // Seed the random number generator
    srand(time(NULL));

    // Create customer threads with random arrival times
    for (int i = 0; i < num_customers; i++) {
        customer_ids[i] = i + 1; // Assign unique IDs to customers
        pthread_create(&customer_threads[i], NULL, customer, &customer_ids[i]);
        sleep(rand() % 3); // Customers arrive at random intervals
    }

    // Join customer threads
    for (int i = 0; i < num_customers; i++) {
        pthread_join(customer_threads[i], NULL);
    }

    // Note: Barber thread runs infinitely. In a real program, you would have a way to terminate it gracefully.

    // Cleanup (unreachable in this implementation)
    pthread_mutex_destroy(&print_lock);
    free(customer_sems);
    free(q.array);

    return 0;
}
