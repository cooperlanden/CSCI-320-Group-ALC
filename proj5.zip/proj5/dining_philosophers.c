#include "common_threads.h"
#include "common.h"
#include "zemaphore.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define THINKING 0
#define HUNGRY 1
#define EATING 2

int N;                 // Number of philosophers
Zem_t *forks;          // Array of semaphores for forks
int *eat_count;        // Array to track the eat count for each philosopher
pthread_mutex_t lock;  // Mutex for synchronizing updates to eat_count

void *philosopher(void *arg) {
    int id = *(int *)arg;

    while (1) {
        printf("Philosopher %d is thinking\n", id);
        sleep(rand() % 3); // Simulate thinking
        printf("Philosopher %d is hungry\n", id);

        // Pick up forks
        Zem_wait(&forks[id]);
        Zem_wait(&forks[(id + 1) % N]);

        // Eating
        pthread_mutex_lock(&lock);
        eat_count[id]++;
        printf("Philosopher %d is eating. Total eat count: %d\n", id, eat_count[id]);
        pthread_mutex_unlock(&lock);
        sleep(rand() % 2); // Simulate eating

        // Put down forks
        Zem_post(&forks[id]);
        Zem_post(&forks[(id + 1) % N]);
    }

    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <num_philosophers>\n", argv[0]);
        return -1;
    }

    N = atoi(argv[1]);
    if (N < 3 || N > 20) {
        printf("Number of philosophers must be between 3 and 20\n");
        return -1;
    }

    forks = malloc(N * sizeof(Zem_t));
    eat_count = malloc(N * sizeof(int));
    pthread_t threads[N];
    int ids[N];

    pthread_mutex_init(&lock, NULL);

    // Initialize semaphores and eat count
    for (int i = 0; i < N; i++) {
        Zem_init(&forks[i], 1);
        eat_count[i] = 0;
        ids[i] = i;
    }

    // Create philosopher threads
    for (int i = 0; i < N; i++) {
        pthread_create(&threads[i], NULL, philosopher, &ids[i]);
    }

    // Join threads (not needed if threads run infinitely)
    for (int i = 0; i < N; i++) {
        pthread_join(threads[i], NULL);
    }

    // Cleanup
    free(forks);
    free(eat_count);
    pthread_mutex_destroy(&lock);

    return 0;
}
