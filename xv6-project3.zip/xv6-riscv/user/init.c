// init: The initial user-level program

#include "kernel/types.h"
#include "kernel/stat.h"
#include "kernel/spinlock.h"
#include "kernel/sleeplock.h"
#include "kernel/fs.h"
#include "kernel/file.h"
#include "user/user.h"
#include "kernel/fcntl.h"

char *argv[] = { "sh", 0 };

int
main(void)
{
  int pid, wpid;

  // Open the console
  if(open("console", O_RDWR) < 0){
    mknod("console", CONSOLE, 0);
    open("console", O_RDWR);
  }
  dup(0);  // stdout
  dup(0);  // stderr

/*
  pid = fork();
  if(pid < 0){
    printf("init: fork for lotterytest failed\n");
    exit(1);
  }
  if(pid == 0){
    // In child process: execute test_lottery
    char *test_argv[] = { "lotterytest", 0 };
    exec("lotterytest", test_argv);
    printf("init: exec lotterytest failed\n");
    exit(1);
  } */
  // In parent process: continue to start the shell

  for(;;){
    printf("init: starting sh\n");
    pid = fork();
    if(pid < 0){
      printf("init: fork failed\n");
      exit(1);
    }
    if(pid == 0){
      exec("sh", argv);
      printf("init: exec sh failed\n");
      exit(1);
    }

    for(;;){
      // Wait for any child process to exit
      wpid = wait((int *) 0);
      if(wpid == pid){
        // The shell exited; restart it.
        break;
      } else if(wpid < 0){
        printf("init: wait returned an error\n");
        exit(1);
      } else {
        
      }
    }
  }
}
