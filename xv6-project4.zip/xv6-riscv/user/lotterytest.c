#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/pstat.h"

void cpu_bound_work() {
    volatile int i;
    for (i = 0; i < 1e8; i++) {
        // Simulate CPU-intensive work
    }
}
 
int main(int argc, char *argv[]) {
    int tickets[] = {30, 20, 10}; // Ticket distribution
    int num_procs = sizeof(tickets) / sizeof(tickets[0]);
    struct pstat stats;
 
    for (int i = 0; i < num_procs; i++) {
        int pid = fork();
        if (pid == 0) { // Child process
            settickets(tickets[i]);
            cpu_bound_work(3);
            exit(0); // Child exits after work
        }
    }
 
    // Parent process monitors statistics
    while (1) {
        if (getpinfo(&stats) < 0) {
            printf("Error: getpinfo failed\n");
            exit(0);
        }
        printf("PID\tTickets\tTicks\n");
        for (int i = 0; i < NPROC; i++) {
            if (stats.inuse[i]) {
                printf("%d\t%d\t%d\n", stats.pid[i], stats.tickets[i], stats.ticks[i]);
            }
        }
        sleep(100); // Sleep to gather periodic data
    }
 
    for (int i = 0; i < num_procs; i++) {
        wait(0); // Wait for all children to finish
    }
 
    exit(0);
}
